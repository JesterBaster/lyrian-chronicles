import { LYRIAN } from "../config.mjs";

/**
 * The Actor document for Lyrian Chronicles.
 * Rolls live here so macros can call them: actor.rollSkill("stealth")
 */
export class LyrianActor extends Actor {
  /** @override */
  prepareData() {
    super.prepareData();
  }

  /* -------------------------------------------- */
  /*  Roll data for formulas                       */
  /* -------------------------------------------- */

  /** @override */
  getRollData() {
    const data = { ...this.system };

    // Shorthands so a GM can write @power or @focus in a formula field.
    for (const [key, stat] of Object.entries(this.system.stats ?? {})) {
      data[key] = stat.total ?? stat.value;
    }
    for (const [key, stat] of Object.entries(this.system.subStats ?? {})) {
      data[key] = stat.total ?? stat.value;
    }

    data.guard = this.system.guard;
    data.evasion = this.system.evasion;
    data.potency = this.system.potency;
    data.spiritCore = this.system.spiritCore ?? 0;

    return data;
  }

  /* -------------------------------------------- */
  /*  Skills                                       */
  /* -------------------------------------------- */

  /**
   * Roll a main skill: d20 + sub stat + ranks + expertise (if applied).
   * @param {string} skillKey
   * @param {object} [options]
   * @param {boolean} [options.useExpertise]
   * @param {number}  [options.dc]
   */
  async rollSkill(skillKey, options = {}) {
    const skill = this.system.skills?.[skillKey];
    if (!skill) return ui.notifications.warn(`Unknown skill: ${skillKey}`);

    const useExpertise = options.useExpertise ?? skill.expertiseRank > 0;
    const bonus = useExpertise ? skill.expertiseTotal : skill.total;
    const label = game.i18n.localize(LYRIAN.skills[skillKey].label);
    const flavourParts = [label];
    if (useExpertise && skill.expertise) flavourParts.push(`(${skill.expertise})`);

    return this._rollCheck({
      formula: `1d20 + ${bonus}`,
      flavour: flavourParts.join(" "),
      dc: options.dc
    });
  }

  /** Roll an artisan crafting check: d10 + skill + expertise. */
  async rollArtisan(skillKey, options = {}) {
    const skill = this.system.artisan?.[skillKey];
    if (!skill) return ui.notifications.warn(`Unknown artisan skill: ${skillKey}`);
    const useExpertise = options.useExpertise ?? skill.expertiseRank > 0;
    const bonus = useExpertise ? skill.expertiseTotal : skill.total;
    return this._rollCheck({
      formula: `1d10 + ${bonus}`,
      flavour: `${game.i18n.localize(LYRIAN.artisanSkills[skillKey])} — Crafting Check`
    });
  }

  /** Roll a gathering strike: d10 + gathering skill. */
  async rollGathering(skillKey, options = {}) {
    const skill = this.system.gathering?.[skillKey];
    if (!skill) return ui.notifications.warn(`Unknown gathering skill: ${skillKey}`);
    return this._rollCheck({
      formula: `1d10 + ${skill.total + (options.bonus ?? 0)}`,
      flavour: `${game.i18n.localize(LYRIAN.gatheringSkills[skillKey])} — Gathering Check`
    });
  }

  /** Resist an effect: 2d10 + Toughness against the caster's Potency. */
  async rollSave(options = {}) {
    return this._rollCheck({
      formula: `2d10 + ${this.system.save}`,
      flavour: game.i18n.localize("LYRIAN.Roll.Save"),
      dc: options.potency
    });
  }

  /**
   * Roll d20 + an arbitrary value. Used for raw stat checks and for
   * contesting a defence number directly when the GM calls for it.
   * @param {string} label   Shown as the chat flavour.
   * @param {number} value   The bonus to add.
   * @param {object} [options]
   * @param {number} [options.dc]
   */
  async rollAttribute(label, value, options = {}) {
    return this._rollCheck({
      formula: `1d20 + ${Number(value) || 0}`,
      flavour: label,
      dc: options.dc
    });
  }

  /** Roll a main stat check: d20 + the stat's total. */
  async rollStat(statKey, options = {}) {
    const stat = this.system.stats?.[statKey] ?? this.system.subStats?.[statKey];
    if (!stat) return ui.notifications.warn(`Unknown stat: ${statKey}`);
    const table = this.system.stats?.[statKey] ? "mainStats" : "subStats";
    const label = game.i18n.localize(LYRIAN[table][statKey]);
    return this.rollAttribute(label, stat.total, options);
  }

  /** Roll initiative outside of the tracker: 1d4 + Agility. */
  async rollInitiativeCheck() {
    return this._rollCheck({
      formula: `1d4 + ${this.system.initiative.value}`,
      flavour: game.i18n.localize("LYRIAN.Roll.Initiative")
    });
  }

  /* -------------------------------------------- */

  async _rollCheck({ formula, flavour, dc }) {
    const roll = await new Roll(formula, this.getRollData()).evaluate();
    let flavorText = flavour;

    if (Number.isNumeric(dc)) {
      const success = roll.total >= dc;
      const tag = success
        ? game.i18n.localize("LYRIAN.Roll.Success")
        : game.i18n.localize("LYRIAN.Roll.Failure");
      flavorText += ` — DC ${dc}: <strong>${tag}</strong>`;
    }

    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: flavorText
    });
    return roll;
  }

  /* -------------------------------------------- */
  /*  Resources                                    */
  /* -------------------------------------------- */

  /**
   * Attempt to pay AP, RP and mana. Returns false and warns if you cannot.
   */
  async spendResources({ ap = 0, rp = 0, mana = 0 } = {}) {
    const s = this.system;
    const shortfalls = [];
    if (ap > s.ap.total) shortfalls.push(`${ap} AP`);
    if (rp > s.rp.total) shortfalls.push(`${rp} RP`);
    if (mana > s.mana.total) shortfalls.push(`${mana} Mana`);

    if (shortfalls.length) {
      ui.notifications.warn(
        game.i18n.format("LYRIAN.Warn.NotEnoughResources", {
          name: this.name,
          cost: shortfalls.join(", ")
        })
      );
      return false;
    }

    const update = {};
    for (const [key, cost] of [["ap", ap], ["rp", rp], ["mana", mana]]) {
      if (!cost) continue;
      // Temporary points are spent first — they expire, so burning them last wastes them.
      const pool = s[key];
      const fromTemp = Math.min(pool.temp ?? 0, cost);
      update[`system.${key}.temp`] = (pool.temp ?? 0) - fromTemp;
      update[`system.${key}.value`] = pool.value - (cost - fromTemp);
    }

    await this.update(update);
    return true;
  }

  /**
   * Refill AP to max at the start of the actor's turn.
   * Temporary AP is left alone — it was granted on top of the normal pool
   * and should survive the refresh until it is spent or cleared by hand.
   */
  async refreshTurn() {
    await this.update({ "system.ap.value": this.system.ap.max });
    // Once-per-round ability locks reset when your turn comes round again.
    const locked = this.items.filter((i) => i.type === "ability" && i.system.usedThisRound);
    if (locked.length) {
      await this.updateEmbeddedDocuments(
        "Item",
        locked.map((i) => ({ _id: i.id, "system.usedThisRound": false }))
      );
    }
  }

  /**
   * Full refresh at the start of an encounter: AP, RP, and per-encounter flags.
   * Temporary AP, RP and mana are preserved. Anything granted before the fight
   * (a Rest interlude, a pre-battle buff) is meant to be available during it.
   */
  async startEncounter() {
    const update = {
      "system.ap.value": this.system.ap.max,
      "system.rp.value": this.system.rp.max
    };
    if (this.type === "character") {
      update["system.encounter.secretArtUsed"] = false;
      update["system.encounter.encounterStartUsed"] = false;
      update["system.encounter.conclusionUsed"] = false;
      update["system.encounter.downedThisEncounter"] = 0;
    }
    await this.update(update);
  }

  /* -------------------------------------------- */
  /*  Damage                                       */
  /* -------------------------------------------- */

  /**
   * Apply damage using the rulebook order: temp HP, then Guard, then HP.
   * @param {number} amount        Rolled damage.
   * @param {object} [options]
   * @param {string} [options.defence]  "none" | "dodge" | "block"
   * @param {boolean} [options.trueDamage]   Ignores Guard and temp HP entirely.
   * @param {boolean} [options.fullPierce]   Ignores Guard but not temp HP.
   * @param {number}  [options.pinpoint]     Ignore this many points of Guard.
   */
  async applyDamage(amount, options = {}) {
    const { defence = "none", trueDamage = false, fullPierce = false, pinpoint = 0 } = options;
    const s = this.system;

    let final = amount;
    let guardUsed = 0;

    if (!trueDamage) {
      if (!fullPierce) {
        const baseGuard = defence === "block" ? s.blockGuard : s.guard;
        guardUsed = Math.max(0, baseGuard - pinpoint);
        final = amount - guardUsed;
      }

      // Only Block (or an equivalent reduction) can take an attack to zero.
      const floor = defence === "block" ? 0 : 1;
      final = Math.max(floor, final);
    }

    // Temp HP absorbs first, and true damage bypasses it.
    let temp = s.hp.temp;
    if (!trueDamage && temp > 0) {
      const absorbed = Math.min(temp, final);
      temp -= absorbed;
      final -= absorbed;
    }

    const newHp = s.hp.value - final;
    const update = { "system.hp.value": newHp, "system.hp.temp": temp };

    await this.update(update);
    await this._checkDowned(newHp);

    return { applied: final, guardUsed, hp: newHp };
  }

  /** Heal, respecting max HP. */
  async applyHealing(amount) {
    const newHp = Math.min(this.system.hp.max, this.system.hp.value + amount);
    await this.update({ "system.hp.value": newHp });
    if (newHp > 0) await this.toggleStatusEffect("downed", { active: false });
    return newHp;
  }

  /* -------------------------------------------- */

  /** Flag Downed at 0 HP and Mortal Wound at negative max HP. */
  async _checkDowned(hp) {
    const max = this.system.hp.max;

    if (hp <= -max) {
      await this.toggleStatusEffect("downed", { active: true });
      await this.toggleStatusEffect("mortalWound", { active: true });
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: this }),
        content: `<p><strong>${this.name}</strong> ${game.i18n.localize("LYRIAN.Msg.MortallyWounded")}</p>`
      });
      return;
    }

    if (hp <= 0) {
      // Grunts die outright; everyone else goes down.
      if (this.type === "npc" && this.system.diesWhenDropped) {
        await this.toggleStatusEffect("dead", { active: true, overlay: true });
        return;
      }
      await this.toggleStatusEffect("downed", { active: true });
      await this.toggleStatusEffect("prone", { active: true });
      if (this.type === "character") {
        await this.update({
          "system.encounter.downedThisEncounter": this.system.encounter.downedThisEncounter + 1
        });
      }
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: this }),
        content: `<p><strong>${this.name}</strong> ${game.i18n.localize("LYRIAN.Msg.Downed")}</p>`
      });
    }
  }

  /* -------------------------------------------- */
  /*  Encounter conclusion                         */
  /* -------------------------------------------- */

  /**
   * Roll 1d10 on the injury table and create the matching Injury item.
   */
  async rollInjury() {
    const roll = await new Roll("1d10").evaluate();
    const entry = LYRIAN.injuryTable[roll.total];
    const name = game.i18n.localize(entry.label);

    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: `${game.i18n.localize("LYRIAN.Roll.Injury")} — <strong>${name}</strong>`
    });

    await this.createEmbeddedDocuments("Item", [
      {
        name,
        type: "injury",
        img: "icons/svg/blood.svg",
        system: { injuryKey: entry.key, rolled: roll.total, fromDowned: true }
      }
    ]);

    return entry;
  }
}
